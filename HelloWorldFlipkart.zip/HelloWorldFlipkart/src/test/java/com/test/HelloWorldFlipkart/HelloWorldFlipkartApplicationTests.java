package com.test.HelloWorldFlipkart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWorldFlipkartApplicationTests {

	@Test
	void contextLoads() {
	}

}
