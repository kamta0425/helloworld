package com.test.HelloWorldFlipkart.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Ride {

    int user_id;
    int vehicle_id;
    String start_location;
    String end_location;
    String start_time;
    int expected_duration;
    int price;
}
