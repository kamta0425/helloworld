package com.test.HelloWorldFlipkart;

public class SearchRideDetail {
    public enum SORTBY {
        PRICE_LOW_TO_HIGH, PRICE_HIGH_TO_LOW, DURATION, START_TIME
    }
    String start_location;
    String end_location;
    SORTBY sort_by;
}
