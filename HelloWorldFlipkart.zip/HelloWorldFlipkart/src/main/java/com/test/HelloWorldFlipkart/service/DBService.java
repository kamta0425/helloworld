package com.test.HelloWorldFlipkart.service;

import com.test.HelloWorldFlipkart.SearchRideDetail;
import com.test.HelloWorldFlipkart.entities.Ride;
import com.test.HelloWorldFlipkart.entities.User;
import com.test.HelloWorldFlipkart.entities.Vehicle;
import java.util.*;
import org.springframework.stereotype.Service;

@Service
public class DBService {

    public User createUser(User user) {
        return null;
    }

    public User createVehicle(Vehicle user) {
        return null;
    }

    public Ride createRide(Ride ride) {
        return null;
    }

    public List<Ride> getRides(SearchRideDetail searchRideDetail) {

        return null;
    }
}
