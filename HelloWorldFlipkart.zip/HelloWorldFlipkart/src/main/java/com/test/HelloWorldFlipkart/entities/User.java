package com.test.HelloWorldFlipkart.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.*;

@Data
@AllArgsConstructor
public class User {
    int user_id;
    String name;
    int age;
    String adhar_nnumber;

    List<Vehicle> vehicles;
}
