package com.test.HelloWorldFlipkart.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Vehicle {
    public enum Cartype {
        SEDAN, SUV
    }

    int vehicle_id;
    Cartype car_type;
    String plate_number;
    String car_model;
}
