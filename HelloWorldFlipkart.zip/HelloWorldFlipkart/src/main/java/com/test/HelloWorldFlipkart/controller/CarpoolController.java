package com.test.HelloWorldFlipkart.controller;

import com.test.HelloWorldFlipkart.Response;
import com.test.HelloWorldFlipkart.SearchRideDetail;
import com.test.HelloWorldFlipkart.entities.Ride;
import com.test.HelloWorldFlipkart.entities.User;
import com.test.HelloWorldFlipkart.entities.Vehicle;
import com.test.HelloWorldFlipkart.service.DBService;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class CarpoolController {

    @Autowired
    DBService dbService;

    @PostMapping("/createUser")
    @ResponseBody
    public Response createUser(@RequestBody User user){
        // validation on user object, if unvalidate return 404
        Response response = null;
        try {
            User createUser = this.dbService.createUser(user);
            for(Vehicle vehicle: user.getVehicles()){
                this.dbService.createVehicle(vehicle);
                //if error roll back user creation
            }

            // created response and retun it
            HashMap<String, Integer> map = new HashMap<>();
            map.put("registeredUserId", createUser.getUser_id());
            if(createUser != null){
                response = new Response(Response.Status.SUCCESS, "", map);
            } else {
                response = new Response(Response.Status.FAILED, "Error while registering user", null);
            }
        } catch (Exception exception){
            response = new Response(Response.Status.FAILED, exception.getMessage(), null);
        }
        return response;
    }

    @PostMapping("/createRide")
    @ResponseBody
    public Response createRide(@RequestBody Ride ride){
        // validation on ride object, if unvalidate return 404
        Response response = null;
        try {
            Ride createdRide = this.dbService.createRide(ride);
            // created response and retun it
            HashMap<String, Integer> map = new HashMap<>();
            map.put("registeredRideId", createdRide.getUser_id());
            if(createdRide != null){
                response = new Response(Response.Status.SUCCESS, "", map);
            } else {
                response = new Response(Response.Status.FAILED, "Error while creating ride", null);
            }
        } catch (Exception exception){
            response = new Response(Response.Status.FAILED, exception.getMessage(), null);
        }
        return response;
    }

    @GetMapping("/getRides")
    @ResponseBody
    public Response getRides(@RequestBody SearchRideDetail searchRideDetail) {
        Response response = null;
        try {
            List<Ride> rides = this.dbService.getRides(searchRideDetail);
            if (rides != null) {
                response = new Response(Response.Status.SUCCESS, "", rides);
            } else {
                response = new Response(Response.Status.FAILED, "Error while fetching ride", null);
            }
        } catch (Exception exception) {
            response = new Response(Response.Status.FAILED, exception.getMessage(), null);
        }
        return response;
    }

}
