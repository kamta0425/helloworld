package com.test.HelloWorldFlipkart.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Location {

    int location_id;
    String location_name;

}
