package com.test.HelloWorldFlipkart;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Response {
    public enum Status {
        SUCCESS, FAILED
    }

    Status status;
    String message;
    Object payload;
}
